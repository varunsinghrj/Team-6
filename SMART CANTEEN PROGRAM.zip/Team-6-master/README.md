hey we here made a programe named smart canteen to manage your canteen 

step 1. download all the programe files
step 2. open "smart_canteen.html" file to go to the main interface here you will see three choices for: menu , feedback and complaint.
step 3. if you have choosen menu bar it will take you to the "menu.html" file there you will get 3 choices for Drinks, Junk Food, Lunch & Dinner.
step 4. if you choose feedback it will take you to "feedback.html" where you can submit your feedback.
step 5. if you choose complaint it will take you to "complaint.html" where you can submit your complain.
step 6. Here Our Simple Short Program  Is Completed.
